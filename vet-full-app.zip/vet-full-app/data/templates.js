window.VET_TEMPLATES = {
  metadata: {
    appName: "Veterinærverktøy for eierinformasjon",
    version: "1.0.0"
  },
  species: {
    dog: {
      label: "Hund",
      diagnoses: {
        uti_dog: {
          label: "Urinveisinfeksjon hos hund",
          defaultAnimalReference: "hunden din",
          levels: {
            standard: {
              intro: [
                "Det kan være bekymringsfullt når hunden din virker syk eller får tydelige plager ved vannlating.",
                "Slike symptomer skaper ofte uro fordi hunden kan virke ukomfortabel, selv om allmenntilstanden ellers kan være ganske god.",
                "Informasjonen under forklarer hva vurderingen betyr og hva det er viktig å følge med på videre."
              ],
              meaning: [
                "Urinveisinfeksjon betyr at det har oppstått en betennelse i urinveiene, som oftest på grunn av bakterier i urinblæren.",
                "Dette kan gi hyppig vannlating, små urinmengder, tydelig trang til å tisse, uhell inne, luktforandring i urinen eller blod i urinen.",
                "Tilstanden er ofte plagsom og kan være smertefull, men er i mange tilfeller håndterbar når den oppdages og følges opp i tide.",
                "Hos noen hunder går plagene raskt over, mens andre trenger nærmere oppfølging dersom symptomene varer ved eller kommer tilbake."
              ],
              why: [
                "Veterinærer kommer vanligvis frem til denne vurderingen ved å se på sykehistorien, symptomene, kliniske funn og ofte urinprøve.",
                "Basert på det som er kjent nå, passer symptomene og funnene best med urinveisinfeksjon hos hund.",
                "Dette er en vurdering per nå. Dersom symptomene endrer seg, blir tydelig verre eller ikke utvikler seg som forventet, kan det være behov for en ny vurdering eller flere undersøkelser."
              ],
              home: [
                "Sørg for at hunden din alltid har tilgang til friskt vann.",
                "Gi gjerne hyppigere lufteturer, slik at urinblæren tømmes regelmessig og hunden slipper å holde seg lenge.",
                "Følg med på hvor ofte hunden tisser, om det kommer små mengder, og om det virker smertefullt.",
                "Eventuell behandling eller plan fra veterinær bør følges slik den er avtalt."
              ],
              contact: [
                "Kontakt veterinær raskere dersom hunden din ikke får til å tisse, bare får ut noen dråper, eller virker tydelig smertepåvirket.",
                "Ny kontakt er også viktig dersom hunden blir slapp, får redusert appetitt, får feberfølelse, kaster opp eller får økende mengde blod i urinen.",
                "Ta også kontakt dersom det ikke blir bedring som forventet, eller dersom plagene kommer tilbake etter kort tid."
              ],
              followUp: [
                "Videre oppfølging avhenger av hvor uttalte symptomene er, hvordan hunden utvikler seg, og om det foreligger prøvesvar eller behov for kontroll.",
                "I noen tilfeller holder det å se utviklingen an hjemme med avtalt oppfølging, mens andre tilfeller bør kontrolleres nærmere."
              ],
              vetSummary: {
                mainAssessment: "Funn og symptomer passer samlet med urinveisinfeksjon hos hund per nå.",
                ownerUnderstanding: "Eier bør forstå at tilstanden ofte gir hyppig vannlating, ubehag og eventuelt blod i urin, men at plagene ofte kan behandles og følges opp.",
                whenToRecontact: "Ny kontakt anbefales ved forverring, feber, nedsatt allmenntilstand, manglende urinering eller dersom symptomene ikke bedres som forventet.",
                followUp: "Videre oppfølging vurderes ut fra symptomer, eventuelle prøvesvar og respons på behandling."
              }
            }
          }
        },
        otitis_dog: {
          label: "Ørebetennelse hos hund",
          defaultAnimalReference: "hunden din",
          levels: {
            standard: {
              intro: [
                "Det kan være urolig når hunden din virker plaget og viser tegn til smerte eller irritasjon fra øret.",
                "Mange eiere merker raskt at hunden rister på hodet, klør seg eller reagerer ved berøring.",
                "Informasjonen under forklarer hva denne vurderingen betyr og hva det er viktig å følge med på hjemme."
              ],
              meaning: [
                "Ørebetennelse betyr at huden i øregangen er irritert eller betent.",
                "Dette kan gi kløe, rødhet, vond lukt, økt ørevoks, smerte og hoderisting.",
                "Tilstanden er vanlig og ofte behandlingsbar, men kan være tydelig ubehagelig for hunden.",
                "Dersom betennelsen får stå lenge, kan den bli mer langvarig eller komme tilbake."
              ],
              why: [
                "Veterinærer vurderer vanligvis dette ut fra symptomer, undersøkelse av øret og hvordan øregangen ser ut.",
                "Basert på det som er kjent nå, passer funnene best med ørebetennelse hos hund.",
                "Dette er en vurdering per nå, og ny vurdering kan være nødvendig dersom plagene ikke bedres eller blir verre."
              ],
              home: [
                "Følg behandlingsplanen nøyaktig dersom øredråper eller annen behandling er avtalt.",
                "Unngå å rense øret mer enn anbefalt.",
                "Følg med på om hunden fortsatt rister mye på hodet eller virker mer smertepåvirket."
              ],
              contact: [
                "Ta kontakt dersom hunden får økende smerter, holder hodet skjevt, mister balansen eller ikke tåler berøring ved øret.",
                "Ny kontakt er også viktig dersom det ikke blir tydelig bedring eller symptomene kommer raskt tilbake."
              ],
              followUp: [
                "Noen hunder trenger kontroll for å sikre at betennelsen er gått tilbake.",
                "Ved gjentatte episoder kan det være behov for å se etter underliggende årsak."
              ],
              vetSummary: {
                mainAssessment: "Funnene passer samlet best med ørebetennelse hos hund per nå.",
                ownerUnderstanding: "Eier bør forstå at tilstanden ofte gir kløe, smerte og irritasjon, men som regel lar seg behandle med riktig oppfølging.",
                whenToRecontact: "Ny kontakt anbefales ved økende smerter, manglende bedring, balanseforstyrrelse eller rask tilbakekomst av symptomer.",
                followUp: "Videre oppfølging avhenger av respons på behandling og om det er mistanke om underliggende årsak."
              }
            }
          }
        }
      }
    },
    cat: {
      label: "Katt",
      diagnoses: {
        gastro_cat: {
          label: "Akutt mage-/tarmirritasjon hos katt",
          defaultAnimalReference: "katten din",
          levels: {
            standard: {
              intro: [
                "Det kan være bekymringsfullt når katten din kaster opp, har løs avføring eller virker utilpass.",
                "Slike symptomer kan komme raskt og skape usikkerhet om hvor alvorlig situasjonen er.",
                "Informasjonen under forklarer hva vurderingen betyr og hva det er viktig å følge med på hjemme."
              ],
              meaning: [
                "Akutt mage-/tarmirritasjon betyr at magesekk eller tarm er irritert, noe som kan gi oppkast, diaré, kvalme eller redusert appetitt.",
                "Hos mange katter er dette forbigående og kan gå over i løpet av kort tid, men noen trenger tettere oppfølging.",
                "Det viktigste er å følge med på allmenntilstand, matinntak, drikking og om katten klarer å holde på væske."
              ],
              why: [
                "Veterinærer vurderer vanligvis dette ut fra sykehistorie, klinisk undersøkelse og hvor påvirket katten virker.",
                "Basert på det som er kjent nå, passer symptomene best med akutt mage-/tarmirritasjon.",
                "Dette er en vurdering per nå, og nye symptomer eller manglende bedring kan gjøre det nødvendig med ny vurdering."
              ],
              home: [
                "Tilby vann og følg med på om katten drikker.",
                "Følg eventuelle råd om fôring og behandling slik de er gitt.",
                "Se etter tegn til ny oppkast, diaré, slapphet eller smerte."
              ],
              contact: [
                "Kontakt veterinær dersom katten blir slapp, ikke vil drikke, kaster opp gjentatte ganger eller får blod i oppkast eller avføring.",
                "Ny kontakt er også viktig dersom katten blir tydelig dårligere eller ikke bedres som forventet."
              ],
              followUp: [
                "I milde tilfeller holder det ofte å se utviklingen an hjemme med avtalt oppfølging.",
                "Ved vedvarende eller tilbakevendende symptomer kan videre utredning være nødvendig."
              ],
              vetSummary: {
                mainAssessment: "Symptomer og funn passer best med akutt mage-/tarmirritasjon hos katt per nå.",
                ownerUnderstanding: "Eier bør forstå at tilstanden ofte er forbigående, men at væskeinntak, appetitt og allmenntilstand må følges nøye.",
                whenToRecontact: "Ny kontakt anbefales ved gjentatt oppkast, redusert drikking, slapphet, blod eller manglende bedring.",
                followUp: "Videre oppfølging styres av utviklingen hjemme og behov for ny vurdering ved forverring."
              }
            }
          }
        }
      }
    }
  }
};
