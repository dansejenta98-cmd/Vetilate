(function () {
  const data = window.VET_TEMPLATES;

  const speciesEl = document.getElementById("species");
  const diagnosisEl = document.getElementById("diagnosis");
  const levelEl = document.getElementById("level");
  const animalReferenceEl = document.getElementById("animalReference");
  const findingsEl = document.getElementById("findings");
  const treatmentEl = document.getElementById("treatment");
  const followUpEl = document.getElementById("followUp");
  const outputEl = document.getElementById("output");
  const diagnosisBadgeEl = document.getElementById("diagnosisBadge");
  const statusTextEl = document.getElementById("statusText");
  const generateBtn = document.getElementById("generateBtn");
  const copyBtn = document.getElementById("copyBtn");
  const resetBtn = document.getElementById("resetBtn");

  function setStatus(message, isSuccess = false) {
    statusTextEl.textContent = message;
    statusTextEl.className = isSuccess ? "success" : "";
  }

  function capitalize(text) {
    if (!text) return text;
    return text.charAt(0).toUpperCase() + text.slice(1);
  }

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function populateSpecies() {
    speciesEl.innerHTML = Object.entries(data.species)
      .map(([value, entry]) => `<option value="${value}">${entry.label}</option>`)
      .join("");
  }

  function populateDiagnoses() {
    const selectedSpecies = speciesEl.value;
    const diagnoses = data.species[selectedSpecies].diagnoses;

    diagnosisEl.innerHTML = Object.entries(diagnoses)
      .map(([value, entry]) => `<option value="${value}">${entry.label}</option>`)
      .join("");

    syncAnimalReference();
    updateBadge();
  }

  function syncAnimalReference() {
    const diagnosis = getCurrentDiagnosis();
    if (!diagnosis) return;
    animalReferenceEl.value = diagnosis.defaultAnimalReference;
  }

  function getCurrentDiagnosis() {
    const selectedSpecies = speciesEl.value;
    const selectedDiagnosis = diagnosisEl.value;
    return data.species[selectedSpecies]?.diagnoses[selectedDiagnosis] || null;
  }

  function getCurrentTemplate() {
    const diagnosis = getCurrentDiagnosis();
    const level = levelEl.value;
    return diagnosis?.levels[level] || null;
  }

  function updateBadge() {
    const diagnosis = getCurrentDiagnosis();
    diagnosisBadgeEl.textContent = diagnosis ? diagnosis.label : "Ingen diagnose valgt";
  }

  function optionalParagraph(title, value) {
    if (!value || !value.trim()) return "";
    return `<p><strong>${escapeHtml(title)}:</strong> ${escapeHtml(value.trim())}</p>`;
  }

  function renderList(items) {
    return `<ul>${items.map(item => `<li>${escapeHtml(item)}</li>`).join("")}</ul>`;
  }

  function buildVetSummary(template, diagnosisLabel, findings, treatment, followUp) {
    const s = template.vetSummary;
    const summaryItems = [
      s.mainAssessment,
      s.ownerUnderstanding,
      s.whenToRecontact,
      s.followUp
    ];

    return `
      <h3>DEL 1: Kort oppsummering for veterinær</h3>
      <p class="muted">Diagnose: ${escapeHtml(diagnosisLabel)} | Informasjonsnivå: standard</p>
      ${renderList(summaryItems)}
      ${optionalParagraph("Kliniske funn / notater", findings)}
      ${optionalParagraph("Tiltak / behandling", treatment)}
      ${optionalParagraph("Oppfølgingsplan", followUp)}
    `;
  }

  function replaceAnimalReference(text, animalReference) {
    return text
      .replaceAll("hunden din", animalReference)
      .replaceAll("katten din", animalReference)
      .replaceAll("dyret ditt", animalReference);
  }

  function buildOwnerSection(template, animalReference, treatment, followUp) {
    const intro = template.intro
      .map(p => `<p>${escapeHtml(replaceAnimalReference(p, animalReference))}</p>`)
      .join("");

    const meaning = template.meaning.map(p => `<p>${escapeHtml(replaceAnimalReference(p, animalReference))}</p>`).join("");
    const why = template.why.map(p => `<p>${escapeHtml(replaceAnimalReference(p, animalReference))}</p>`).join("");
    const homeList = template.home.map(item => replaceAnimalReference(item, animalReference));
    const contactList = template.contact.map(item => replaceAnimalReference(item, animalReference));
    const followUpParagraphs = template.followUp.map(p => `<p>${escapeHtml(replaceAnimalReference(p, animalReference))}</p>`).join("");

    return `
      <h3>DEL 2: Informasjon til dyreeier</h3>
      ${intro}
      <h4>Hva dette betyr</h4>
      ${meaning}
      <h4>Hvorfor denne vurderingen</h4>
      ${why}
      <h4>Hva du kan gjøre hjemme</h4>
      ${renderList(homeList)}
      ${optionalParagraph("Tiltak som er avtalt", treatment)}
      <h4>Når du bør kontakte veterinær</h4>
      ${renderList(contactList)}
      <h4>Videre oppfølging</h4>
      ${followUpParagraphs}
      ${optionalParagraph("Avtalt oppfølging", followUp)}
    `;
  }

  function generateOutput() {
    const diagnosis = getCurrentDiagnosis();
    const template = getCurrentTemplate();

    if (!diagnosis || !template) {
      outputEl.innerHTML = "<p>Kunne ikke lage tekst. Kontroller valg i skjemaet.</p>";
      setStatus("Kunne ikke generere tekst.");
      return;
    }

    const findings = findingsEl.value;
    const treatment = treatmentEl.value;
    const followUp = followUpEl.value;
    const animalReference = animalReferenceEl.value;

    const vetSection = buildVetSummary(template, diagnosis.label, findings, treatment, followUp);
    const ownerSection = buildOwnerSection(template, animalReference, treatment, followUp);

    outputEl.innerHTML = `${vetSection}${ownerSection}`;
    updateBadge();
    setStatus("Tekst generert.", true);
  }

  function copyOutput() {
    const plainText = outputEl.innerText.trim();
    if (!plainText) {
      setStatus("Det er ingen tekst å kopiere.");
      return;
    }

    navigator.clipboard.writeText(plainText)
      .then(() => setStatus("Teksten er kopiert.", true))
      .catch(() => setStatus("Kopiering mislyktes. Marker teksten manuelt og kopier."));
  }

  function resetForm() {
    findingsEl.value = "";
    treatmentEl.value = "";
    followUpEl.value = "";
    speciesEl.value = "dog";
    populateDiagnoses();
    levelEl.value = "standard";
    outputEl.innerHTML = "<p>Velg diagnose og trykk <strong>Lag tekst</strong>.</p>";
    setStatus("Feltene er nullstilt.");
  }

  speciesEl.addEventListener("change", populateDiagnoses);
  diagnosisEl.addEventListener("change", () => {
    syncAnimalReference();
    updateBadge();
  });
  generateBtn.addEventListener("click", generateOutput);
  copyBtn.addEventListener("click", copyOutput);
  resetBtn.addEventListener("click", resetForm);

  populateSpecies();
  speciesEl.value = "dog";
  populateDiagnoses();
  diagnosisEl.value = "uti_dog";
  syncAnimalReference();
  updateBadge();
  generateOutput();
})();
